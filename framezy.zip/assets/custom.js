window.addEventListener("beforeunload", function (event) {
  // document.getElementById("page-loader").style.opacity = "1";
});