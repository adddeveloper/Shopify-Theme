
  AVADA_SC.campaigns = [];
  AVADA_SC.settings = {};
  