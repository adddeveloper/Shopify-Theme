document.addEventListener("DOMContentLoaded", function() {
  const preloader = document.getElementById('preloader');
   setTimeout(function() {
  preloader.classList.add('active');
 setTimeout(function() {
      preloader.classList.add('active-1');
      }, 1000); 
  }, 2000); 



});

